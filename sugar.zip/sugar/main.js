/** SUGAR SYNTAX **/

//¿Qué es? La utilización de operadores avanzados con la idea de simplificar nuestro código. 

//1) Plantillas literales: `` las usamos a traves de las backsticks
//alt + 96. Esto me permite simplificar la concatenación de datos. 

let nombre = "Pepe Argento";
let trabajo = "Zapatería"; 

let mensaje = `${nombre} trabaja en una ${trabajo} `;
console.log(mensaje);


//2) Operador Ternario: Es una simplificación de la estructura if/else. 

//Sintaxis: condicion ? codigoSiEsVerdad : codigoSiEsFalso;

let frio = false;

console.log(frio ? "mira netflix con la estufa" : "hacemos un picnic"); 

let respuesta = frio ? "sopaipillas y star+" : "hacemos un asado";

console.log(respuesta);

//3) Operador Spread: operador de propagación (...)
//Se utiliza con elementos iterables ( arrays, objetos ) enviando cada uno de sus elementos como parámetros a una función. 

let nombres = ["Juan", "Pedro", 100, "Jose"];

console.log(nombres);

//Peeeeeeeeeero si utilizo el operador spread: 

console.log(...nombres);

//Igual a hacer esto: 

console.log(nombres[0], nombres[1], nombres[2], nombres[3]);

//Lo usamos para copiar objetos: 

const comida = {
    nombre: "Pastel de Choclo",
    precio: 2000,
    peso: 500
}

const otraComida = comida;
//Si hago esto estoy copiando la referencia en memoria. 

otraComida.precio = 5000; 

//console.log(comida);
//console.log(otraComida);

//Para copiar información de forma correcta utilizo el operador spread: 

const comidaDos = {...comida}; 
comida.precio = 10000;
console.log(comida);
console.log(comidaDos);

//Copiamos arrays: 

const a = [1,2,3];
const b = [4,5,6];

const nuevoArrayCombinado = [...a, ...b];
console.log(nuevoArrayCombinado);

//4) Desestructuración de objetos: 

//Es una expresión de JS que me permite desempaquetar valores de arrays u objetos en distintas variables. 


const bart = {
    nombre: "Bart",
    apellido: "Simpsons",
    edad: 10,
    escuela: "Sprinfield Elementary School"
};

let {nombre:nombrecito, apellido, edad, escuela} = bart;

console.log(nombrecito);
console.log(apellido);
console.log(escuela);


//5) Desestructuración de Arrays: 

let frutas = ["Manzana", "Pera", "Naranja", "Vino"];

let [,, fruta2, fruta3] = frutas;

console.log(fruta2);

//6) Acceso Condicional a Propiedades de un Objeto (?)

const empleado = null;

console.log(empleado?.nombre);

alert("Ayudame Loco!");

//Lo utilizo para controlar errores y evitar que se rompa la aplicación. 








